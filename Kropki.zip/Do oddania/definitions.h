#include<stdio.h>
#include <cairo.h>
#include <gtk/gtk.h>
#include <math.h>
#include <sys/stat.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>
#include<ctype.h>

#define RADIOUS 5
#define GAP 25
#define WIDTH_MAX 50
#define HEIGHT_MAX 50
