#include"definitions.h"
#include"fifo.h"

void fifo_init(int argc, char *argv[]);
void send_info(int index);
void get_info(int *ans);
int string_to_int(char text[]);
