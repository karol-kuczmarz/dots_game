#include"base.h"

void move(int map[], frame *lines, int chosen, int *opp_points, int *my_points, int const WIDTH, int const HEIGHT);
void pointsandverify(int map[], int mapcopy[],  int mapcopy2[], int *opp_points, int *my_points, int const WIDTH, int const HEIGHT);
